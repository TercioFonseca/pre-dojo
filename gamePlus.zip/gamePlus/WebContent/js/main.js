var myApp = angular.module('myApp', []);

myApp.directive('fileModel', ['$parse', function ($parse) {
    return {
        restrict: 'A',
        link: function(scope, element, attrs) {
            var model = $parse(attrs.fileModel);
            var modelSetter = model.assign;
            
            element.bind('change', function(){
                scope.$apply(function(){
                    modelSetter(scope, element[0].files[0]);
                });
            });
        }
    };
}]);

myApp.service('fileUpload', ['$http', function ($http) {
    this.uploadFileToUrl = function(file, uploadUrl, callback, errorBack){
        var fd = new FormData();
        fd.append('file', file);
        $http.post(uploadUrl, fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        	
        })
        .success(function(data, status, headers, config){
        	callback(data);
        })
        .error(function(data, status, headers, config){
        	errorBack();
        });
    }
}]);



myApp.service('getOnServer', ['$http', function ($http) {
    this.getFrom = function(url, callback, errorBack){
        
        $http.get(url)
        .success(function(data, status, headers, config){
        	callback(data);
        })
        .error(function(data, status, headers, config){
        	errorBack();
        });
    }
}]);

myApp.controller('myCtrl', ['$scope', 'fileUpload', 'getOnServer', function($scope, fileUpload, getOnServer){
    $scope.path = null;
    var baseURL = "http://localhost:8070/gamePlus/rest";
    
    $scope.getAllPrepared  = function(){  
    	debugger;
    	if($scope.path!=null)
    	getOnServer.getFrom(baseURL + "/match/get/"+$scope.path, 
    	   callback = function(data){
    		debugger;
    		$scope.MatchList = data;
    		
    	}, errorBack =  function(){
    		
    		
    		
    	});   	
    }
    $scope.uploadFile = function(){
    	
        var file = $scope.myFile;
        console.log('file is ' );
        console.dir(file);
        var uploadUrl = baseURL + "/match/upload";
        fileUpload.uploadFileToUrl(file, uploadUrl, 
           callback = function(data){
        	
        	 $scope.path= data;
        	
        	
        	
        }, errorback = function(data){
        	
        	
        	
        });
    };
    
    
    $scope.$watch('MatchList',function(){
    	if($scope.MatchList!=null)
    	alert("pei");
    })
    
}]);
