package br.com.game.model;

public enum EnumGame {

	ZERO(0), UM(1), DOIS(2), TRES(3), QUATRO(4), CINCO(5), SEIS(6), SETE(7), OITO(8), NOVE(9), DEZ(10);

	private final int value;

	EnumGame(int enumGame) {
		value = enumGame;
	}

	public int getValue() {
		return value;
	}

}
