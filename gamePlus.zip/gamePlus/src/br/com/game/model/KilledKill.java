package br.com.game.model;

import java.io.Serializable;

public class KilledKill implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 8459253232506236555L;
	private String aux;
	private String hasKilled;
	private String killed;
	public String getAux() {
		return aux;
	}
	public void setAux(String aux) {
		this.aux = aux;
	}
	public String getHasKilled() {
		return hasKilled;
	}
	public void setHasKilled(String hasKilled) {
		this.hasKilled = hasKilled;
	}
	public String getKilled() {
		return killed;
	}
	public void setKilled(String killed) {
		this.killed = killed;
	}
	
	
}
