package br.com.game.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonBackReference;

@XmlRootElement
public class Match implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3553033161589844712L;



	public Match(){
		this.players = new ArrayList<Player>();
	}
	
	private String code;	
	private List<Player> players;
	private int sumKill;
	private Timestamp start;
	private Timestamp finished;
	
	
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public List<Player> getPlayers() {
		return players;
	}
	public void setPlayers(Player players) {
		this.players.add(players);
		
	}
	public int getSumKill() {
		return sumKill;
	}
	public void setSumKill(int sumKill) {
		this.sumKill = sumKill;
	}
	
	public Timestamp getStart() {
		return start;
	}
	public void setStart(Timestamp start) {
		this.start = start;
	}
	public Timestamp getFinished() {
		return finished;
	}
	public void setFinished(Timestamp finished) {
		this.finished = finished;
	}
	
	
}
