package br.com.game.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonBackReference;

@XmlRootElement
public class Player implements Comparable<Player>, Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7172213343715997512L;

	public Player(){
		this.playersKilled = new ArrayList<>();
		this.playersHasKilled = new ArrayList<>();		
	}
	
	private String name;
	private int killed;
	private int hasKilled;
	private Timestamp dateTimeAction;
	private String gun;
	
	private List<KilledKill> playersKilled;
	
	private List<KilledKill> playersHasKilled;
	private int condeMatch;
	private Player aux;
	
	public Player getAux() {
		return aux;
	}
	public void setAux(Player aux) {
		this.aux = aux;
	}
	public int getCondeMatch() {
		return condeMatch;
	}
	public void setCondeMatch(int condeMatch) {
		this.condeMatch = condeMatch;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getKilled() {
		return killed;
	}
	public void setKilled(int killed) {
		this.killed = killed;
	}
	public int getHasKilled() {
		return hasKilled;
	}
	public void setHasKilled(int hasKilled) {
		this.hasKilled = hasKilled;
	}
	public Timestamp getDateTimeAction() {
		return dateTimeAction;
	}
	public void setDateTimeAction(Timestamp dateTimeAction) {
		this.dateTimeAction = dateTimeAction;
	}
	public String getGun() {
		return gun;
	}
	public void setGun(String gun) {
		this.gun = gun;
	}
	public List<KilledKill> getPlayersKilled() {
		return playersKilled;
	}
	public void setPlayersKilled(KilledKill player) {
		this.playersKilled.add(player);
		
	}
	public List<KilledKill> getPlayersHasKilled() {
		return playersHasKilled;
	}
	public void setPlayersHasKilled(KilledKill object) {
		this.playersHasKilled.add( object);
		
	}
	@Override
	public int compareTo(Player player) {
		if(this.playersKilled.size()> player.playersKilled.size())
			return -1;
		if(this.playersKilled.size()< player.playersKilled.size())
			return 1;
		
		return 0;
	}
	
	
	
	

}
