package br.com.game.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import br.com.game.model.EnumGame;
import br.com.game.model.KilledKill;
import br.com.game.model.Match;
import br.com.game.model.Player;
import br.com.game.util.DateConverter;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

@Path("/match")
public class MatchService {

	private List<Match> list;
	private static final String SERVER_UPLOAD_LOCATION_FOLDER = "C://upload/";

	public List<Match> GetListMatch() {
		return list;
	}

	@POST
	@Path("/upload")
//	@Consumes({"application/x-www-form-urlencoded", "*/*"})	
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces("text/plain")
	public Response uploadFile(@FormDataParam("file") InputStream fileInputStream,
			@FormDataParam("file") FormDataContentDisposition contentDispositionHeader) {

		String filePath = SERVER_UPLOAD_LOCATION_FOLDER + contentDispositionHeader.getFileName();

		// save the file to the server
		saveFile(fileInputStream, filePath);
		Response teste = Response.status(200).entity(contentDispositionHeader.getFileName()).type("text/plain").build();
			return teste;


	}
	
	
	

	@GET
	@Path("/get/{file}")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Match> getAllPrepared(@PathParam("file") String locationFile) {
		MatchService service = new MatchService();
		service.GetFileinListGame(SERVER_UPLOAD_LOCATION_FOLDER+locationFile);
		service.buildObjects(SERVER_UPLOAD_LOCATION_FOLDER+locationFile);

		List list = service.GetListMatch();

		return (ArrayList<Match>) service.getListProcessed(list);
	}

	
	private boolean saveFile(InputStream uploadedInputStream, String serverLocation) {

		try {
			OutputStream outpuStream = new FileOutputStream(new File(serverLocation));
			int read = 0;
			byte[] bytes = new byte[1024];

			outpuStream = new FileOutputStream(new File(serverLocation));
			while ((read = uploadedInputStream.read(bytes)) != -1) {
				outpuStream.write(bytes, 0, read);
			}
			outpuStream.flush();
			outpuStream.close();
			return true;
		} catch (IOException e) {

			e.printStackTrace();
			return false;
		}

	}

	public List<String> GetFileinListGame(String namePath) {
		List<String> stringList = new ArrayList();
		BufferedReader br = null;
		String sCurrentLine;
		try {

			br = new BufferedReader(new FileReader(namePath));
			while ((sCurrentLine = br.readLine()) != null) {
				stringList.add(sCurrentLine);
			}

			return stringList;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	// metodo que varre linha por linha do log montando construindo os objetos
	// de partidas e jogadores
	public void buildObjects(String namePath) {
		list = new ArrayList<Match>();

		List<String> buildList = GetFileinListGame(namePath);
		Match match = new Match();
		for (String line : buildList) {

			String[] shortLine = new String[EnumGame.DEZ.getValue()];
			shortLine = line.split(" ");

			if (line.contains("has started"))
				if (line.contains("New match")) {
					match.setCode(shortLine[EnumGame.CINCO.getValue()]);
					match.setStart(DateConverter.StringToTimestamp(
							shortLine[EnumGame.ZERO.getValue()] + " " + shortLine[EnumGame.UM.getValue()]));
				}

			if (line.contains("killed")) {
				Player player = new Player();
				player.setName(shortLine[EnumGame.TRES.getValue()]);
				player.setGun(shortLine[EnumGame.SETE.getValue()]);
				player.setDateTimeAction(DateConverter.StringToTimestamp(
						shortLine[EnumGame.ZERO.getValue()] + " " + shortLine[EnumGame.UM.getValue()]));
				KilledKill killed = new KilledKill();
				killed.setKilled(shortLine[EnumGame.CINCO.getValue()]);
				killed.setHasKilled(player.getName());
				player.setPlayersKilled(killed);
				match.setPlayers(player);
			}

			if (line.contains("has ended"))
				if (line.contains("Match")) {
					match.setFinished(DateConverter.StringToTimestamp(
							shortLine[EnumGame.ZERO.getValue()] + " " + shortLine[EnumGame.UM.getValue()]));
					list.add(match);
					match = new Match();
				}
		}

	}

	public List<Match> getListProcessed(List<Match> listMatch) {
		List<Match> newList = new ArrayList<Match>();

		int cont = 0;
		for (Match match : listMatch) {
			Match newMatch = new Match();
			newMatch.setCode(match.getCode());
			newMatch.setStart(match.getStart());
			newMatch.setFinished(match.getFinished());

			for (Player player : match.getPlayers()) {

				if (newMatch.getPlayers().size() != 0) {
					for (Player playSub : newMatch.getPlayers()) {
						if (playSub.getName().equals(player.getName())) {
							if (player.getPlayersKilled().size() != 0)
								playSub.setPlayersKilled(player.getPlayersKilled().get(EnumGame.ZERO.getValue()));
							if (player.getPlayersHasKilled().size() != 0)
								playSub.setPlayersHasKilled(player.getPlayersHasKilled().get(EnumGame.ZERO.getValue()));
							break;

						} else {
							cont++;
							if (cont == newMatch.getPlayers().size()) {
								newMatch.setPlayers(player);

								cont = 0;
								break;
							}
						}
					}

				} else {
					newMatch.setPlayers(player);
				}

			}
			//ordeno por quem matou mais
			Collections.sort(newMatch.getPlayers());
			newList.add(newMatch);

			ArrayList<KilledKill> myArray = new ArrayList<KilledKill>();

			//monta lista de jogadores que foram mortos de cada player
			for (Player p : newMatch.getPlayers()) {
				myArray.addAll(p.getPlayersKilled());

			}

			//Verifico se o jogador atual est� na lista de mortos de outro jogador
			for (Player p : newMatch.getPlayers()) {
				for (KilledKill h : myArray) {
					if (p.getName().equals(h.getKilled())) {
						KilledKill temp = new KilledKill();
						temp.setAux(h.getHasKilled());
						p.setPlayersHasKilled(temp);
					}

				}
			}

		}

		return newList;

	}


}
