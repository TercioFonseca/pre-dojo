package br.com.game.service;

import java.util.List;

public class Teste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MatchService service = new MatchService();
		service.GetFileinListGame("D:/game/game.log");		
		service.buildObjects("D:/game/game.log");
		
		List list = service.GetListMatch();
		
		List listProcessed = service.getListProcessed(list);

	}

}
