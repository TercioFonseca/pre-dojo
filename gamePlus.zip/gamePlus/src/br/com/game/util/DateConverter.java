package br.com.game.util;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateConverter {
	
	
	public static Timestamp StringToTimestamp(String stringDate){
		//23/04/2013 15:34:22
		try{
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Date date = dateFormat.parse(stringDate);
		long time = date.getTime();
		return new Timestamp(time);
		}catch(Exception e){			
			e.printStackTrace();
			return null;
		}
		
		
	}

}
